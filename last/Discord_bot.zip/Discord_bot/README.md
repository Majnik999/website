<h1>Multi tool project</h1>

This `discord` bot yes `discord` bot is full of goods like play command and more...

So to run this bot first install `reqirements.txt` and got to `src/config.py` there you can configure the bot like set token and more...

Before starting please in `console` in your project (if you have it in with `virtual enviroment` do it there) run command `playwright install` to install this is the library for the bot so it can do more but the library yes is in the `reqirements.txt` but it need to be installed with this command.

Now you can start.

If there are any `errors` just ak me on `dicord` `majnik999_yt` (my name).

The bot has hidden commands like:

* `exit` - This command will turn off bot
* `restart` - This command will restart the bot
* `adwebhook` - If you have token for other bot this command can send message with the `token` | `Usage`: (prefix)adwebhook (token) (channel_id) (message)

`Do not worry the message with the adwebhook command will be deleted by bot so other don't see the token`.