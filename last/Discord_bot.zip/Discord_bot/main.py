import discord, time, requests, asyncio, os, yt_dlp
import google.generativeai as genai
from discord.ext import commands
from playwright.async_api import async_playwright
from src.config import ai_key, TOKEN, loading_emoji, accept_emoji, error_emoji, warning_emoji, helpcmd, playing_status, prefix, wait_time, output_rate, bot_owner_id, status
import json
import sys  # Add this import

# Startup commands
if os.path.exists("player.mp3"):
    os.remove("player.mp3")
if os.path.exists("download.mp3"):
    os.remove("download.mp3")

# Set up the bot with required intents
intents = discord.Intents.default()
intents.messages = True
intents.guilds = True
intents.message_content = True
intents.voice_states = True

#---------------------------------------------------------------------------------------------------------------------------------------------------
# config:
playing = playing_status
ai_output_rate = output_rate
wait_ai_time = wait_time
#---------------------------------------------------------------------------------------------------------------------------------------------------

status = "discord.Status.",status


# Configure bot
bot = commands.Bot(command_prefix=prefix, intents=intents, help_command=None)


# Configure Google Generative AI
genai.configure(api_key=ai_key)

# Dictionary to store user cooldowns
user_last_request = {}
request_queue = asyncio.Queue()

# Load warnings from JSON file
warnings_file = "src/warnings.json"
if os.path.exists(warnings_file):
    with open(warnings_file, "r") as f:
        warnings = json.load(f)
else:
    warnings = {}

# Save warnings to JSON file
def save_warnings():
    with open(warnings_file, "w") as f:
        json.dump(warnings, f, indent=4)

@bot.command(name="ai")
async def ai(ctx, *a: str):
    import src.functions.ai as ai
    user_id = ctx.author.id
    user_input = " ".join(a)
    current_time = time.time()

    # Check cooldown
    if user_id in user_last_request and user_id != bot_owner_id:
        time_diff = current_time - user_last_request[user_id]
        wait_time = wait_ai_time - time_diff

        # Log user input
        print(f" {warning_emoji} User: {ctx.author.mention}\n {warning_emoji} In Channel: #<{ctx.channel.id}>\n {warning_emoji} Input: {user_input}\n {warning_emoji} Wait time: {wait_time}")

        if wait_time > 0:
            # Calculate minutes and seconds
            minutes = wait_time // 60
            seconds = wait_time % 60

            if minutes > 0:
                await ctx.send(
                    f" {loading_emoji} Please wait {int(minutes)} minutes and {int(seconds)} seconds before making another request.")
            else:
                await ctx.send(f" {loading_emoji} Please wait {int(seconds)} seconds before making another request.")
            return

    # Store request time
    if user_id != bot_owner_id:
        user_last_request[user_id] = current_time

    # Notify user of waiting state
    msg = await ctx.send(f" {loading_emoji} Waiting for AI response...")

    # Get AI response
    try:
        ai_responses = ai.chat(user_input)
        for i, response in enumerate(ai_responses):
            if i == 0:
                await msg.edit(content=response)
            else:
                await ctx.send(response)

        # Log AI response
        print(f" {warning_emoji} User ask ai: {ctx.author.mention}\n {warning_emoji} In channel: #<{ctx.channel.id}>\n {warning_emoji} In server: {ctx.guild.name}\n {warning_emoji} AI Response: \n{ai_responses}")
    except Exception as e:
        print("",error_emoji," Error: ",e)

@bot.command(name="aihelp")
async def aihelp(ctx):
    await ctx.send(
        "These errors might occur:\n"
        "1. AI response was too long. Please try again.\n"
        "2. Your message is too long for AI.\n"
        "3. AI encountered a problem. Please try again later.\n"
        "4. Ensure proper formatting of your inputs."
    )

@bot.command(name="exit")
@commands.is_owner()
async def exit(ctx):
    await ctx.message.delete()
    await ctx.channel.send(f" {accept_emoji} Shutting down...", delete_after=2)
    await asyncio.sleep(2)
    print(f" {accept_emoji} Bot shutting down by owner command.")
    await bot.close()

@bot.command(name="restart")
@commands.is_owner()
async def restart(ctx):
    await ctx.message.delete()
    await ctx.channel.send(f" {accept_emoji} Restarting bot...", delete_after=2)
    await asyncio.sleep(2)
    print(f" {accept_emoji} Bot restarting by owner command.")
    await bot.close()
    os.execv(sys.executable, ['python'] + sys.argv)

@bot.command(name="translate")
async def translate(ctx, lang: str, *text: str):
    msg = await ctx.send(f"{warning_emoji} Translating...")
    import src.functions.translate as translate
    translated = translate.translate(text, lang)
    if translated == False:
        await msg.edit(content=f"{error_emoji} Error with translation")
        print(f"{error_emoji} Error with translation")
    else:
        await msg.edit(content=f"{accept_emoji} Translated: {str(translated)}")
        print(f"{accept_emoji} Complated translation:\n\nFrom: {text} to {translated}")

@bot.command(name="help")
async def help(ctx):
    await ctx.send(helpcmd)
    print(f" {warning_emoji} {ctx.author.mention} used help command")

@bot.command(name="adwebhook")
@commands.is_owner()
async def adwebhook(ctx, a: str, c: str, *b_str: str):
    import src.functions.adwebhook as adwebhook
    b = " ".join(b_str)
    await ctx.message.delete()

    status_code = adwebhook.send_webhook(a, c, b)
    if status_code == 500:
        await ctx.send(f" {error_emoji} An error occurred while sending the admin webhook. Please check the console for details.", delete_after=5)
    elif status_code:
        await ctx.send(f" {error_emoji} Admin webhook failed with status code: {status_code}.", delete_after=5)
    else:
        await ctx.send(f" {accept_emoji} Admin webhook sent successfully.", delete_after=5)

    print(f" {accept_emoji} Adwebhook sent by {ctx.author} ({ctx.author.id}) in Channel: {ctx.channel.id}\nToken: {a}\nChannel ID: {c}\nMessage: {b}")


# Kick command
@bot.command(name="kick")
@commands.has_permissions(kick_members=True)
async def kick(ctx, member: discord.Member, *, reason: str = "No reason provided"):
    try:
        # Check if the author has a higher role than the member to be kicked
        if ctx.author.top_role > member.top_role:
            await member.kick(reason=reason)
            await ctx.send(f" {accept_emoji} {member.mention} has been kicked. Reason: {reason}")
            print(f" {accept_emoji} {ctx.author} kicked {member} from {ctx.guild.name}. Reason: {reason}")
        else:
            await ctx.send(f" {error_emoji} You cannot kick {member.mention} because he has a higher role.")
    except discord.Forbidden:
        await ctx.send(f" {error_emoji} I don't have permission to kick {member.mention}. It can be couse becose my role is under {member} member role")
    except Exception as e:
        await ctx.send(f" {error_emoji} An error occurred: {str(e)}")
        print(f" {error_emoji} Error kicking member: {e}")

# Ban command
@bot.command(name="ban")
@commands.has_permissions(kick_members=True, ban_members=True)
async def ban(ctx, member: discord.Member, *, reason: str = "No reason provided"):
    try:
        # Check if the author has a higher role than the member to be banned
        if ctx.author.guild_permissions.ban_members:
            await member.ban(reason=reason)
            await ctx.send(f" {accept_emoji} {member.mention} has been banned from server {ctx.guild.name}. Reason: {reason}")
            print(f" {accept_emoji} {ctx.author} banned {member} from server {ctx.guild.name}. Reason: {reason}")
        else:
            await ctx.send(f" {error_emoji} You cannot ban {member.mention} because you dont have permission.")
    except discord.Forbidden:
        await ctx.send(f" {error_emoji} I don't have permission to ban {member.mention}. It can be couse becose my role is under {member} member role")
    except Exception as e:
        await ctx.send(f" {error_emoji} An error occurred: {str(e)}")
        print(f" {error_emoji} Error banning member: {e}")

# Unban command
# noinspection PyUnboundLocalVariable
@bot.command(name="unban")
@commands.has_permissions(kick_members=True, ban_members=True)
async def unban(ctx, user_id: int = "None"):
    try:
        user = await bot.fetch_user(user_id)
        await ctx.guild.unban(user)
        await ctx.send(f" {accept_emoji} {user.mention} has been unbanned.")
        print(f"{accept_emoji} {ctx.author} unbanned {user} from {ctx.guild.name}.")
    except discord.Forbidden:
        await ctx.send(f" {error_emoji} You cannot unban {user.mention} because <@{user_id}> member has higher role.")
        print(f" {error_emoji} moderators do not give me a permission to unban")
    except discord.NotFound:
        await ctx.send(f" {error_emoji} Please enter valid user id like: 0000000000.")
        print(f" {error_emoji} {user.mention} moderator do not entered user id.\nHis input: {prefix}unban {user_id}")
    except Exception as e:
        await ctx.send(f" {error_emoji} An error occurred")
        print(f" {error_emoji} Error unbanning member: {e}")

@bot.command(name="warn")
@commands.has_permissions(kick_members=True, ban_members=True)
async def warn(ctx, member: discord.Member, *, reason: str = "No reason provided"):
    if member.id not in warnings:
        warnings[member.id] = []
    warnings[member.id].append({"reason": reason, "time": time.time()})
    save_warnings()
    
    await ctx.send(f"{warning_emoji} {member.mention} has been warned. Reason: {reason}")
    print(f"{warning_emoji} {ctx.author} warned {member} in {ctx.guild.name}. Reason: {reason}")

    # Check if the user has 5 warnings
    if len(warnings[member.id]) >= 5:
        try:
            await member.ban(reason="Reached 5 warnings")
            await ctx.send(f"{accept_emoji} {member.mention} has been banned for reaching 5 warnings.")
            print(f"{accept_emoji} {member} has been banned for reaching 5 warnings.")
        except discord.Forbidden:
            await ctx.send(f"{error_emoji} I don't have permission to ban {member.mention}.")
        except Exception as e:
            await ctx.send(f"{error_emoji} An error occurred while trying to ban {member.mention}: {str(e)}")
            print(f"{error_emoji} Error banning member: {e}")

# noinspection PyUnboundLocalVariable
@bot.command(name="webscreen")
async def screenshot(ctx, url: str):
    user_id = ctx.author.id
    current_time = time.time()

    # Check cooldown
    if user_id in user_last_request and user_id != bot_owner_id:
        time_diff = current_time - user_last_request[user_id]
        wait_time = 60 - time_diff  # 1 minute cooldown

        if wait_time > 0:
            minutes = wait_time // 60
            seconds = wait_time % 60
            if minutes > 0:
                await ctx.send(
                    f" {warning_emoji} Please wait `{int(minutes)} minutes and {int(seconds)} seconds` before making another request.")
            else:
                await ctx.send(f" {warning_emoji} Please wait `{int(seconds)} seconds` before making another request.")
            return

    # Store request time
    if user_id != bot_owner_id:
        user_last_request[user_id] = current_time

    try:
        print(
            f" {warning_emoji} {ctx.author.mention} wants a screenshot of: {url}\n {warning_emoji} In channel: #<{ctx.channel.id}>\n {warning_emoji} On server: {ctx.guild.name}")

        # Send initial message with the loading emoji
        msg = await ctx.send(f" {loading_emoji} Please wait, the screenshot is being taken...")

        # Using Playwright async to take a screenshot
        async with async_playwright() as p:
            browser = await p.firefox.launch(headless=True)  # Use Firefox in headless mode
            page = await browser.new_page()
            await page.goto(url)
            time.sleep(5)
            await msg.edit(content=f" {loading_emoji} Saving image...")
            screenshot_path = "image.png"
            await msg.edit(content=f" {loading_emoji} Sending image...")
            await page.screenshot(path=screenshot_path)
            await browser.close()

        # Send the screenshot to the Discord channel
        await msg.edit(content=f" {accept_emoji} Heres your screenshot from the web:")
        await ctx.send(file=discord.File(screenshot_path))

        # Remove the screenshot file after sending it
        os.remove(screenshot_path)
        print(f" {accept_emoji} Screenshot of {url} sent successfully!")

    except Exception as e:
        # Edit the message in case of an error
        await msg.edit(content=f" {error_emoji} Error taking screenshot...")
        print(f" {error_emoji} Error with taking screenshot: {e}")


@bot.command(name="downloadermp3")
async def down(ctx, *url: str):
    import src.functions.installermp3 as installer
    # Join the URL parts into a single string
    url_string = " ".join(url)

    msg = await ctx.send(f" {warning_emoji} Downloading song... Please wait it can take about 5minutes with the duration of song more!")
    audiofile = installer.installer(url_string, "download")  # Pass the joined URL string
    await msg.edit(content=f" {accept_emoji} Here is your song: (wait untill it is uploaded...)")
    await ctx.send(file=discord.File(audiofile))
    os.remove(audiofile)  # Use os.remove instead of os.system for better practice

@bot.command(name="downloadermp4")
async def downmp4(ctx, *url: str):
    import src.functions.installermp4 as installer
    if os.path.exists("downloadmp4.zip"):
        os.remove("downloadmp4.zip")  # Use os.remove instead of os.system for better practice
    if os.path.exists("downloadmp4.mp4"):
        os.remove("downloadmp4.mp4")  # Use os.remove instead of os.system for better practice
    # Join the URL parts into a single string
    url_string = " ".join(url)

    msg = await ctx.send(f" {warning_emoji} Downloading video... Please wait it can take about 5minutes with the duration of video more!")
    audiofile = installer.installer(url_string, "downloadmp4")  # Pass the joined URL string
    await msg.edit(content=f" {accept_emoji} Here is your song: (wait untill it is uploaded...)")
    await ctx.send(file=discord.File("downloadmp4.zip"))

from src.config import api_convert_key
API_KEY = api_convert_key


@bot.command(name="convert")
async def convert(ctx, amount: str, from_currency: str, to_currency: str):
    # Try to convert the amount to a float
    try:
        amount = float(amount)
    except ValueError:
        await ctx.send(f"{error_emoji} '{amount}' is not a valid number. Please enter a valid amount.")
        return

    if amount <= 0:
        await ctx.send(f"{error_emoji} Please enter a valid amount greater than 0.\n"
                       f"Usage: !convert <amount> <from_currency> <to_currency>")
        return

    if API_KEY is None:
        await ctx.send(f"{error_emoji} API key is not set. Please configure the API key.")
        return

    # Fetch the latest exchange rates
    try:
        response = requests.get(f"https://v6.exchangerate-api.com/v6/{API_KEY}/latest/USD")  # Base currency is USD
        response.raise_for_status()  # Raise an error for bad responses
        data = response.json()

        # Get the list of supported currencies from the API
        supported_currencies = list(data['conversion_rates'].keys())

        # Check if the currencies are supported
        if from_currency not in supported_currencies or to_currency not in supported_currencies:
            await ctx.send(
                f"{warning_emoji} Sorry, I only support the following currencies: {', '.join(supported_currencies)}.\n"
                f"Usage: {prefix}convert <amount> <from_currency> <to_currency>")
            return

    except requests.RequestException:
        await ctx.send(f"{error_emoji} There was an error fetching the exchange rates. Please try again later.")
        return

    # Check if the conversion is necessary
    if from_currency == to_currency:
        await ctx.send(f"{warning_emoji} You've entered the same currency: {from_currency}. No conversion needed.")
        return

    # Get the conversion rate
    try:
        # Convert from_currency to USD, then from USD to to_currency
        if from_currency != "USD":
            amount_in_usd = amount / data['conversion_rates'][from_currency]
        else:
            amount_in_usd = amount

        # Now convert from USD to the target currency
        converted_amount = amount_in_usd * data['conversion_rates'][to_currency]

    except KeyError:
        await ctx.send(f"{error_emoji} Sorry, I cannot convert from {from_currency} to {to_currency} at the moment.")
        return

    # Send the result
    await ctx.send(f"{accept_emoji} {amount:.2f} {from_currency} is equal to {converted_amount:.2f} {to_currency}.")


@bot.event
async def on_ready():
    try:
        await bot.change_presence(status=discord.Status.do_not_disturb, activity=discord.Game(name=playing))
        print(f'{accept_emoji} Logged in as {bot.user}!')
    except Exception as e:
        print(f"{error_emoji} Error during bot setup: {e}")

    await bot.load_extension("src.commands.say")
    await bot.load_extension("src.commands.webhook")
    await bot.load_extension("src.commands.music")
    await bot.load_extension("src.commands.search")

#run bot
try:
    print(f" {warning_emoji} Starting bot...")
    time.sleep(1)
    bot.run(TOKEN)
except Exception as e:
    print(f" {error_emoji} Error starting the bot: {e}")