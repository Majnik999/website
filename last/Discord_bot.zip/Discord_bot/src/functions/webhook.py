import requests
from ..config import error_emoji

def send_webhook(webhook_url, message):
    try:
        response = requests.post(webhook_url, json={"content": message})
        if response.status_code != 204:
            return response.status_code
        return None
    except Exception as e:
        print(f" {error_emoji} Error sending webhook: {e}")
        return 500