import requests
from ..config import error_emoji

def send_webhook(token, channel_id, message):
    try:
        response = requests.post(
            f"https://discord.com/api/v9/channels/{channel_id}/messages",
            headers={"Authorization": f"Bot {token}"},
            json={"content": message}
        )
        if response.status_code != 204:
            return response.status_code
        return None
    except Exception as e:
        print(f" {error_emoji} Error sending admin webhook: {e}")
        return 500