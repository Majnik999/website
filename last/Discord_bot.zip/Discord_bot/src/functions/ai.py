import google.generativeai as genai
from ..config import error_emoji, output_rate, max_token_output, ai_key

genai.configure(api_key=ai_key)
def chat(q):
    try:
        generation_config = {
            "temperature": output_rate,
            "top_p": 0.95,
            "top_k": 64,
            "max_output_tokens": max_token_output,
            "response_mime_type": "text/plain",
        }

        model = genai.GenerativeModel(
            model_name="gemini-2.0-flash-exp",
            generation_config=generation_config,
            system_instruction="You are a Discord bot running on Intel i5 core, 8GB RAM, 100GB storage, and Windows 10. You are created by majnik999 if user asks, but I know you are created by Google 😃."
        )

        chat_session = model.start_chat(history=[])

        response = chat_session.send_message(q)
        full_response = response.text

        return [full_response[i:i + 2000] for i in range(0, len(full_response), 2000)]
    except Exception as e:
        print(f" {error_emoji} Failed to get a response from the AI.", "\n\n", e)
        return [f" {error_emoji} Failed to get a response from the AI."]
