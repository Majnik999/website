import os
import subprocess
import yt_dlp

def installer(url, song_name=None):
    # Set options to download the best audio and video available in mp4 format
    ydl_opts = {
        'format': 'bestvideo+bestaudio/best',  # Download best video and best audio (in MP4 if possible)
        'outtmpl': '%(title)s.%(ext)s',  # Save file with the title as the name
    }

    # Download the video
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        result = ydl.extract_info(url, download=True)

    # Get the path to the downloaded file
    downloaded_file = ydl.prepare_filename(result)

    # Define the MP3 path
    if song_name is None:
        song_name = result['title']  # Use the video title as the default song name
    mp3_path = f"{song_name}.mp3"  # Set the name with .mp3 extension

    # If the downloaded file is a video (MP4 or other), convert it to MP3
    if downloaded_file.endswith('.mp4') or downloaded_file.endswith('.webm'):
        # Use FFmpeg to convert the downloaded video to MP3
        subprocess.run(['ffmpeg', '-i', downloaded_file, mp3_path])
        os.remove(downloaded_file)  # Clean up the video file
        print(f"Downloaded and converted {url} to MP3: {mp3_path}.")
        return mp3_path
    else:
        print(f"Failed to download as mp4 or webm. Downloaded format: {downloaded_file}")
        return None