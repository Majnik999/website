from deep_translator import GoogleTranslator

def translate(text, target_lang):
    """Translates text using deep-translator while handling tuple errors."""
    try:
        # Ensure text is a string
        if isinstance(text, tuple):
            text = " ".join(text)  # Convert tuple to string

        # Check if text is empty
        if not isinstance(text, str) or text.strip() == "":
            return "❌ Error: No valid text provided for translation."

        # Perform translation
        translation = GoogleTranslator(source="auto", target=target_lang).translate(text)
        return f"{translation}"

    except Exception as e:
        return False