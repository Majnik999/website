from pytube import Search

def search(quary):
    # Perform a search on YouTube
    search_query = quary
    search = Search(search_query)

    # Get the first result
    if search.results:
        result = search.results[0].watch_url
        print(f"Finded: {result}")
        return result
    else:
        print("No results found.")
        return None