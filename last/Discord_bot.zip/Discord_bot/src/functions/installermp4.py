import yt_dlp
import os
import zipfile

def installer(url, song_name=None):
    # Set options to download best MP4 video and best audio
    ydl_opts = {
        'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]',  # Ensure MP4 format
        'outtmpl': '%(title)s.%(ext)s',  # Save file with the title as the name
    }

    # Download the video
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        result = ydl.extract_info(url, download=True)

    # Get the path to the downloaded file
    downloaded_file = ydl.prepare_filename(result)

    # Define the song name for the MP4 file
    if song_name is None:
        song_name = result['title']  # Use the video title as the default song name
    mp4_path = f"{song_name}.mp4"  # Set the name with .mp4 extension

    # If the downloaded file is an MP4, we keep it as is
    if downloaded_file.endswith('.mp4'):
        # Rename the downloaded file to match the song name
        os.rename(downloaded_file, mp4_path)
        print(f"Downloaded {url} as MP4: {mp4_path}.")

        # Zip the MP4 file
        zip_file = f"{song_name}.zip"
        with zipfile.ZipFile(zip_file, 'w', zipfile.ZIP_DEFLATED) as zipf:
            zipf.write(mp4_path, os.path.basename(mp4_path))

        print(f"Zipped the file as {zip_file}.")
        return zip_file
    else:
        print(f"Failed to download as MP4. Downloaded format: {downloaded_file}")
        return None