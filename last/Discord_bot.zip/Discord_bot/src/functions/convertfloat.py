from discord.ext import commands

class FloatConverter(commands.Converter):
    async def convert(self, ctx, argument):
        try:
            return float(argument)
        except ValueError:
            raise commands.BadArgument(f"'{argument}' is not a valid number.")