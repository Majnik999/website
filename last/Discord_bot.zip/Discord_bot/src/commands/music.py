import yt_dlp
import asyncio
import discord
from discord.ext import commands
from ..config import warning_emoji
from ..config import accept_emoji
from ..config import loading_emoji
from ..config import error_emoji

class MusicSystem(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.voice_clients = {}  # Store voice clients per guild
        self.yt_dl_options = {"format": "bestaudio/best"}
        self.ytdl = yt_dlp.YoutubeDL(self.yt_dl_options)
        self.current_volume = {}  # Store volume per guild
        self.now_playing = {}  # Store currently playing song per guild
        self.repeat = {}  # Store repeat status per guild
        self.current_time = {}  # Store current time per guild
        self.song_data = {}  # Store song data per guild

    def toggle_repeat(self, guild_id):
        """Toggle repeat status for the current song."""
        if guild_id in self.repeat:
            self.repeat[guild_id] = not self.repeat[guild_id]
        else:
            self.repeat[guild_id] = True

    def after_song(self, guild_id):
        """Handle song end event."""
        if self.repeat.get(guild_id, False):
            current_song_url = self.now_playing.get(guild_id)
            if current_song_url:
                player = discord.FFmpegOpusAudio(current_song_url,
                                                 before_options='-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5',
                                                 options=f'-vn -filter:a "volume={self.current_volume.get(guild_id, 1.0)}"')
                self.voice_clients[guild_id].play(player, after=lambda e: self.after_song(guild_id))

    @commands.command(name="play")
    async def play(self, ctx, *, q: str):
        """Play a song with the given query."""
        from ..functions import search as sch
        msg = await ctx.send(f" {warning_emoji} Getting ready...")

        # Stops the song that is currently playing
        if ctx.guild.id in self.voice_clients and self.voice_clients[ctx.guild.id].is_playing():
            self.voice_clients[ctx.guild.id].stop()


        url = sch.search(q)  # Get song URL

        try:
            # Connect to voice if not already
            if ctx.guild.id not in self.voice_clients:
                await msg.edit(content=f" {loading_emoji} Joining...")
                voice_client = await ctx.author.voice.channel.connect()
                self.voice_clients[ctx.guild.id] = voice_client
            else:
                voice_client = self.voice_clients[ctx.guild.id]

            await msg.edit(content=f" {loading_emoji} Searching...")

            # Download song data
            loop = asyncio.get_event_loop()
            data = await loop.run_in_executor(None, lambda: self.ytdl.extract_info(url, download=False))
            song_url = data['url']

            # Save now playing info
            self.now_playing[ctx.guild.id] = song_url  # Store the URL for volume adjustment
            self.current_time[ctx.guild.id] = 0  # Initialize current time
            self.song_data[ctx.guild.id] = data  # Store song data

            # Get volume (default 100%)
            volume = 1.0

            # Apply volume
            player = discord.FFmpegPCMAudio(song_url, before_options='-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5',
                                            options=f'-vn -filter:a "volume={volume}"')
            voice_client.play(discord.PCMVolumeTransformer(player, volume=volume), after=lambda e: self.after_song(ctx.guild.id))
            await msg.edit(content=f" {accept_emoji} Now playing: at {int(volume * 100)}% volume\n\n**{url}**")

        except Exception as e:
            await msg.edit(content=f" {error_emoji} Error playing song")
            print(e)

    @commands.command(name="pause")
    async def pause(self, ctx):
        """Pause playback."""
        try:
            self.voice_clients[ctx.guild.id].pause()
            await ctx.send(f" {accept_emoji} Music paused.")
        except:
            await ctx.send(f" {error_emoji} No audio playing.")

    @commands.command(name="resume")
    async def resume(self, ctx):
        """Resume playback."""
        song_data = self.song_data.get(ctx.guild.id)
        song_url = self.now_playing.get(ctx.guild.id, None)
        youtube_url = song_data.get('webpage_url', song_url)
        try:
            self.voice_clients[ctx.guild.id].resume()
            await ctx.send(f" {accept_emoji} Msuic resumed. Playing: {youtube_url}")
        except:
            await ctx.send(f" {error_emoji} No audio playing.")

    @commands.command(name="stop")
    async def stop(self, ctx):
        """Stop playback and disconnect."""
        song_data = self.song_data.get(ctx.guild.id)
        song_url = self.now_playing.get(ctx.guild.id, None)
        youtube_url = song_data.get('webpage_url', song_url)
        try:
            self.voice_clients[ctx.guild.id].stop()
            await self.voice_clients[ctx.guild.id].disconnect()
            del self.voice_clients[ctx.guild.id]
            del self.now_playing[ctx.guild.id]
            await ctx.send(f" {accept_emoji} Player removed. Was playing: {youtube_url}")
        except:
            await ctx.send(f" {error_emoji} No audio playing.")

    @commands.command(name="volume")
    async def volume(self, ctx, volume: int):
        """Set playback volume (0-100%)."""
        if 0 <= volume <= 100:
            self.current_volume[ctx.guild.id] = volume / 100.0  # Convert to 0.0-1.0 range
            await ctx.send(f" {accept_emoji} Volume set to {volume}%.")

            # Adjust the volume of the currently playing song
            if ctx.guild.id in self.voice_clients and self.voice_clients[ctx.guild.id].is_playing():
                voice_client = self.voice_clients[ctx.guild.id]
                voice_client.source.volume = self.current_volume[ctx.guild.id]

        else:
            await ctx.send(f" {error_emoji} Volume must be between 0 and 100.")

    @commands.command(name="minfo")
    async def now_playing_cmd(self, ctx):
        """Show current playing song."""
        song_url = self.now_playing.get(ctx.guild.id, None)
        if song_url:
            song_data = self.song_data.get(ctx.guild.id)
            if song_data:
                youtube_url = song_data.get('webpage_url', song_url)
                await ctx.send(f" {accept_emoji} Now playing: **{youtube_url}**")
            else:
                await ctx.send(f" {error_emoji} No song data available.")
        else:
            await ctx.send(f" {error_emoji} No song currently playing.")

    @commands.command(name="repeat")
    async def repeat(self, ctx):
        """Repeat the current song."""
        song_url = self.now_playing.get(ctx.guild.id, None)
        if song_url:
            self.toggle_repeat(ctx.guild.id)
            song_data = self.song_data.get(ctx.guild.id)
            if song_data:
                youtube_url = song_data.get('webpage_url', song_url)
                if self.repeat[ctx.guild.id]:
                    await ctx.send(f" {accept_emoji} Repeating: **{youtube_url}**")
                else:
                    await ctx.send(f" {accept_emoji} Repeat mode disabled.")
            else:
                await ctx.send(f" {error_emoji} No song data available.")
        else:
            await ctx.send(f" {error_emoji} No song currently playing.")

    @commands.command(name="skip")
    async def skip(self, ctx, seconds: int):
        """Skip forward or backward in the music by a specified number of seconds."""
        voice_client = self.voice_clients.get(ctx.guild.id)
        if voice_client and voice_client.is_playing():
            # Calculate new time
            current_time = self.current_time.get(ctx.guild.id, 0)
            new_time = max(0, current_time + seconds)

            # Check if the new time exceeds the song duration
            song_data = self.song_data.get(ctx.guild.id)
            if song_data:
                duration = song_data.get('duration', 0)
                if new_time > duration:
                    await ctx.send(f" {error_emoji} Cannot skip beyond the song duration. The song is {duration} seconds long.")
                    return

            self.current_time[ctx.guild.id] = new_time

            # Stop the current player
            voice_client.stop()
            current_song_url = self.now_playing.get(ctx.guild.id)
            if current_song_url:
                # Recreate the player with the new time
                player = discord.FFmpegPCMAudio(current_song_url, before_options=f'-ss {new_time} -reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5',
                                                options=f'-vn -filter:a "volume={self.current_volume.get(ctx.guild.id, 1.0)}"')
                voice_client.play(discord.PCMVolumeTransformer(player, volume=self.current_volume.get(ctx.guild.id, 1.0)))
                await ctx.send(f" {accept_emoji} Skipped {seconds} seconds. Current song time: {new_time} seconds.")
        else:
            await ctx.send(f" {error_emoji} No audio playing.")

async def setup(bot):
    await bot.add_cog(MusicSystem(bot))