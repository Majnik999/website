from discord.ext import commands
from ..config import loading_emoji
from ..config import accept_emoji
from ..config import error_emoji


class Search(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="search")
    async def search(self, ctx, *, a: str):
        """Search for a song or video."""
        from ..functions import search as sch
        msg = await ctx.send(f" {loading_emoji} Searching...")

        result = sch.search(a)  # Assuming this function returns a string or None
        if result:
            # Get the first result
            print(f" {accept_emoji} Found: {result}\nFor user: {ctx.author.mention}\nOn server: {ctx.guild.name}")
            await msg.edit(content=f" {accept_emoji} Found: {result}")
        else:
            await msg.edit(content=f" {error_emoji} No results found for: **{a}**")


async def setup(bot):
    await bot.add_cog(Search(bot))