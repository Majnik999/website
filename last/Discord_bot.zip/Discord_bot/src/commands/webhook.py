from discord.ext import commands
from ..config import accept_emoji
from ..config import error_emoji

class Webhookc(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="webhook")  # This ensures that the command is "webhook"
    async def webhook(self, ctx, a: str, *b_str: str):
        from ..functions import webhook as wb
        b = " ".join(b_str)

        status_code = wb.send_webhook(a, b)
        if status_code == 500:
            await ctx.send(f"{error_emoji} An error occurred while sending the webhook. Please check the console for details.")
        elif status_code:
            await ctx.send(f"{error_emoji} Webhook failed with status code: {status_code}.")
        else:
            await ctx.send(f"{accept_emoji} Webhook sent successfully.")

        print(f"{accept_emoji} Webhook sent by {ctx.author} ({ctx.author.id}) in Channel: {ctx.channel.id}\nURL: {a}\nMessage: {b}")

async def setup(bot):
    await bot.add_cog(Webhookc(bot))  # Ensure the cog is added correctly
