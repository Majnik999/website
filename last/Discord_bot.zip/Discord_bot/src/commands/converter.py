import os
import requests
from discord.ext import commands
from ..config import warning_emoji, accept_emoji, error_emoji, api_convert_key

class Converter(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.api_key = api_convert_key  # Set the API key as an instance variable

    @commands.command(name="convert")
    async def convert(self, ctx, amount: str, from_currency: str, to_currency: str):
        """Convert an amount from one currency to another."""
        # Try to convert the amount to a float
        try:
            amount = float(amount)
        except ValueError:
            await ctx.send(f"{error_emoji} '{amount}' is not a valid number. Please enter a valid amount.")
            return

        if amount <= 0:
            await ctx.send(f"{error_emoji} Please enter a valid amount greater than 0.\n"
                           f"Usage: !convert <amount> <from_currency> <to_currency>")
            return

        if self.api_key is None:
            await ctx.send(f"{error_emoji} API key is not set. Please configure the API key.")
            return

        # Fetch the latest exchange rates
        try:
            response = requests.get(f"https://v6.exchangerate-api.com/v6/{self.api_key}/latest/USD")  # Base currency is USD
            response.raise_for_status()  # Raise an error for bad responses
            data = response.json()

            # Get the list of supported currencies from the API
            supported_currencies = list(data['conversion_rates'].keys())

            # Check if the currencies are supported
            if from_currency not in supported_currencies or to_currency not in supported_currencies:
                await ctx.send(
                    f"{warning_emoji} Sorry, I only support the following currencies: {', '.join(supported_currencies)}.\n"
                    f"Usage: !convert <amount> <from_currency> <to_currency>")
                return

        except requests.RequestException as e:
            await ctx.send(f"{error_emoji} There was an error fetching the exchange rates: {str(e)}. Please try again later.")
            return

        # Check if the conversion is necessary
        if from_currency == to_currency:
            await ctx.send(f"{warning_emoji} You've entered the same currency: {from_currency}. No conversion needed.")
            return

        # Get the conversion rate
        try:
            # Convert from_currency to USD, then from USD to to_currency
            if from_currency != "USD":
                amount_in_usd = amount / data['conversion_rates'][from_currency]
            else:
                amount_in_usd = amount

            # Now convert from USD to the target currency
            converted_amount = amount_in_usd * data['conversion_rates'][to_currency]

        except KeyError:
            await ctx.send(f"{error_emoji} Sorry, I cannot convert from {from_currency} to {to_currency} at the moment.")
            return

        # Send the result
        await ctx.send(f"{accept_emoji} {amount:.2f} {from_currency} is equal to {converted_amount:.2f} {to_currency}.")

# Setup function to add the cog to the bot
def setup(bot):
    bot.add_cog(Converter(bot))