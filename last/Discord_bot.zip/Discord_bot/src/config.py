# Emojis
error_emoji:   str = "❌"
accept_emoji:  str = "✅"
warning_emoji: str = "⚠️"
loading_emoji: str = "<a:discord_loading:1320359569071013939>"

# Bot information
prefix:         str = "mt"
TOKEN:          str = ""
bot_owner_id:   int = 0
status:         str = "do_not_distrub" # Chose from ❤️: do_not_distrub | 💚: online | 💛: idle (the emojis are like that because when i do the circle its shadow no color so)
helpcmd:        str = f"""
**Commands**

    `help` - Shows this
    `ai` - Chat with AI
    `aihelp` - Help for AI
    `ban` - Ban member | usage: {prefix}ban (@member)
    `unban` - Unban member | usage: {prefix}unban (member id)
    `warn` - Warn member | usage: {prefix}warn (@member)
    `kick` - Kick member | usage: {prefix}kick (@member)
    `webhook` - Sends webhook | usage: {prefix}webhook (url) (text)
    `webscreen` - Sends screenshot from website url
    `downloadermp3` - Download's song with Youtube url
    `downloadermp4` - Download's video with Youtube url
    `search` - Search's Youtube for video url good for combinate with `downloadermp3` 
    `translate` - Translate any text | usage: {prefix}translate (lenguage) (text to translate)
    `say` - Bot says what you want to say from bot!
    `convert` - Convert any number of price to a diffrent price

**Music commands**

    `play` - Play's audio from url or quary
    `pause` - Pause's the playing audio
    `resume` - Resume's the paused audio
    `stop` - Stops the audio player (please do this when the bot is done with playing audio)
    `skip` - Skip's the audio that is playing
    `volume` - Set's the volume of the audio player
    `minfo` - Shows the now playing music info

**Beta commands**

    There none new commands that are in beta

If the output of command is not showing the bot has a too much commands requests!
Add me with this: [here](https://discord.com/oauth2/authorize?client_id=1320063744948048054&permissions=8&integration_type=0&scope=bot)"""
playing_status: str = "mthelp"



# AI

ai_key:           str = ""

max_token_output: int = 2000
output_rate:      int = 0
wait_time:        int = 120 #in seconds

# Commands help configs
# convert command

api_convert_key: str = ""

